from torch.utils.data import Dataset


class HumanPoseEstimationDataset(Dataset):
    """
    HumanPoseEstimationDataset class.

    Generic class for HPE datasets.
    """
    def __init__(self):
        pass

    def __len__(self):
        pass

    def __getitem__(self, item):
        pass

    def evaluate_accuracy(self, output, target, params=None):
        pass
